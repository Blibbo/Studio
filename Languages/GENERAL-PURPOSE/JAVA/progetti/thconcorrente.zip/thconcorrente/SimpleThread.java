/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package thconcorrente;

/**
 *
 * @author Alunno
 */
public class SimpleThread extends Thread {
    public SimpleThread(String str){
        super(str);
    }
    
    public void run(){
        double rd;
        rd=Math.random()*3;
        rd=(rd<1) ? 1 : ((rd<2) ? 2 : 3);
        
        for(int i=0;i<10;i++){
            System.out.println(i+" "+getName());
            
            try{
                sleep((long)(Math.random()*1000*rd));
            }catch(InterruptedException e){
                
            }
        }
        System.out.println("DONE " + getName()+"("+rd+")");
    }
}
