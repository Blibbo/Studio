			<script src="myScript.js">
				
			</script>
		</center>
	</body>
</html>